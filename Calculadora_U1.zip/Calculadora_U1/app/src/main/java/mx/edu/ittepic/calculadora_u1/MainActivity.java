package mx.edu.ittepic.calculadora_u1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
        Button uno,dos,tres,cuatro,cinco,seis,siete,ocho,nueve,cero,mas,menos,multi,divi,punto, borrar, borrarTodo,igual;
        TextView enPantalla;
        Double cadena1,cadena2,total;
        int op;

        String cadena;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Button uno=findViewById(R.id.BT_1);
        Button dos=findViewById(R.id.BT_2);
        Button tres=findViewById(R.id.BT_3);
        Button cuatro=findViewById(R.id.BT_4);
        Button cinco=findViewById(R.id.BT_5);
        Button seis=findViewById(R.id.BT_6);
        Button siete=findViewById(R.id.BT_7);
        Button ocho=findViewById(R.id.BT_8);
        Button nueve=findViewById(R.id.BT_9);
        Button cero=findViewById(R.id.BT_0);

        Button div=findViewById(R.id.BT_DIV);
        Button multi=findViewById(R.id.BT_POR);
        Button mas=findViewById(R.id.BT_MAS);
        Button menos=findViewById(R.id.BT_MEN);

        Button igual=findViewById(R.id.BT_IGUAL);

        final Button borrar=findViewById(R.id.BT_BORRAR);
        Button borrarTodo=findViewById(R.id.BT_BORRARTODO);

        final TextView enPantalla=findViewById(R.id.TEXTO);

        cadena=enPantalla.getText().toString();


        uno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText(cadena+"1");
                cadena=enPantalla.getText().toString();
            }
        });

        dos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText(cadena+"2");
                cadena=enPantalla.getText().toString();
            }
        });

        tres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText(cadena+"3");
                cadena=enPantalla.getText().toString();
            }
        });

        cuatro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText(cadena+"4");
                cadena=enPantalla.getText().toString();
            }
        });

        cinco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText(cadena+"5");
                cadena=enPantalla.getText().toString();
            }
        });

        seis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText(cadena+"6");
                cadena=enPantalla.getText().toString();
            }
        });

        siete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText(cadena+"7");
                cadena=enPantalla.getText().toString();
            }
        });

        ocho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText(cadena+"8");
                cadena=enPantalla.getText().toString();
            }
        });

        nueve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText(cadena+"9");
                cadena=enPantalla.getText().toString();
            }
        });

        cero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText(cadena+"0");
                cadena=enPantalla.getText().toString();
            }
        });

        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //cadena.substring(0, cadena.length() - 1);
                enPantalla.setText(cadena.substring(0, cadena.length() - 1));
                cadena=enPantalla.getText().toString();
            }
        });

        borrarTodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enPantalla.setText("");
                cadena=enPantalla.getText().toString();
            }
        });

        mas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadena1 = Double.parseDouble(cadena);
                enPantalla.setText("+");
                op = 1;
                cadena = "";
            }
        });

        menos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadena1 = Double.parseDouble(cadena);
                enPantalla.setText("-");
                op = 2;
                cadena = "";
            }
        });

        multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadena1 = Double.parseDouble(cadena);
                enPantalla.setText("x");
                op = 3;
                cadena = "";

            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadena1 = Double.parseDouble(cadena);
                enPantalla.setText("/");
                cadena = "";
                op = 4;
            }
        });

        igual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadena2 = Double.parseDouble(cadena);

                switch (op){
                    case 1:
                        total = cadena1 + cadena2;
                        enPantalla.setText(String.valueOf(total));
                        cadena=enPantalla.getText().toString();
                        break;

                    case 2:
                        total = cadena1 - cadena2;
                        enPantalla.setText(String.valueOf(total));
                        cadena=enPantalla.getText().toString();
                        break;

                    case 3:
                        total = cadena1 * cadena2;
                        enPantalla.setText(String.valueOf(total));
                        cadena=enPantalla.getText().toString();
                        break;

                    case 4:
                        total = cadena1 / cadena2;
                        enPantalla.setText(String.valueOf(total));
                        cadena=enPantalla.getText().toString();
                        break;
                }
            }
        });



    }
}
