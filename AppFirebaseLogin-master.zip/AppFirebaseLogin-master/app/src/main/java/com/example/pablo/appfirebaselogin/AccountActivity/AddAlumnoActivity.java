package com.example.pablo.appfirebaselogin.AccountActivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.pablo.appfirebaselogin.AccountActivity.Objetos.Alumno;
import com.example.pablo.appfirebaselogin.AccountActivity.Objetos.FirebaseReferences;
import com.example.pablo.appfirebaselogin.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddAlumnoActivity extends AppCompatActivity {
    DatabaseReference myRef;
    Button btn_add_alumno;
    EditText et_noctrl_alumno;
    EditText et_nombre_alumno;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_alumno);
        btn_add_alumno=findViewById(R.id.btn_add_alumno);
        et_noctrl_alumno=findViewById(R.id.et_nocrtl_alumno);
        et_nombre_alumno=findViewById(R.id.et_nombre_alumno);

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference(FirebaseReferences.TUTORIAL_REFERENCE);
    }

    public void onClickAddAlumno(View view){
        Alumno alumno =new Alumno(Integer.parseInt(et_noctrl_alumno.getText().toString()),
                et_nombre_alumno.getText().toString());
        myRef.child(FirebaseReferences.ALUMNO_REFERENCE).push().setValue(alumno);
    }

    public void onClickListarAlumno(View view){
        Intent intent = new Intent(this,ListaAlumnosActivity.class);
        startActivity(intent);
    }
}
