package com.example.pablo.appfirebaselogin.AccountActivity.Objetos;

/**
 * Created by pablo on 17/04/18.
 */

public class FirebaseReferences {
    final public static String TUTORIAL_REFERENCE="tutorial";
    final public static String ALUMNO_REFERENCE="alumnos";
}
