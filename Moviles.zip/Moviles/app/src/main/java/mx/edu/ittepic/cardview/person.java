package mx.edu.ittepic.cardview;

/**
 * Created by osaos on 28/02/2018.
 */

class Person {
    String name;
    String age;
    int photoId;

    Person(String name, String age, int photoId) {
        this.name = name;
        this.age = age;
        this.photoId = photoId;
    }
}