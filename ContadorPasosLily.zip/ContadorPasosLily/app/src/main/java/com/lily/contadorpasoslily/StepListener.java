package com.lily.contadorpasoslily;

/**
 * Created by osaos on 10/05/2018.
 */

// Will listen to step alerts
public interface StepListener {

    public void step(long timeNs);

}
